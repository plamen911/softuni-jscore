// https://judge.softuni.bg/Contests/Compete/Index/342#1
'use strict';
let mapSort = require('./helper-functions');

result.mapSort = mapSort;

// let map = new Map();
// map.set(3, "Pesho");
// map.set(1, "Gosho");
// map.set(7, "Aleks");
// console.log(mapSort(map));
