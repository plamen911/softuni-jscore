// https://judge.softuni.bg/Contests/Compete/Index/342#2
'use strict';

let sort = require('./load-data').sort;
let filter = require('./load-data').filter;

result.sort = sort;
result.filter = filter;

// console.log(sort('shipTo'));
// console.log(filter('status', 'shipped'));